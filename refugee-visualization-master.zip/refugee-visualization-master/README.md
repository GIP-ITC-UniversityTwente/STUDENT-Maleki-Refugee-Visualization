# refugee-visualization
This application present means of visualizing the UNHCR Refugee dataset over the years of 2003 to 2014.
